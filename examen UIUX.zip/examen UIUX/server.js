import express from "express"
import mongoose from "mongoose"
import User from "./user.js"
const app = express()
const port = 9090
const hostname ="127.0.0.1"

mongoose.connect("mongodb://127.0.0.1:27017/examen")
.then(()=> console.log('connected'))
.catch(()=>console.log('fail'))

app.post("/user/login",(req,res)=> {
User.findOne(req.body)
.then((user)=> res.status(200).json(user))
.catch((err)=>res.status(404).json(err) )

})

app.listen(port ,hostname,()=> {

   

    console.log(`running http://${hostname}:${port}`)
    User.create({email : "admin",password :"admin"})
    .then((user)=> console.log('ok'))
.catch((err)=>console.log('fail'))
})